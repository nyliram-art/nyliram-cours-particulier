import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  // Identifiant unique de l'app (à personnaliser)
  appId: 'com.nyliram.coursparticulier',
  appName: 'Nyliram Cours Particulier',

  // Dossier de build Vite
  webDir: 'dist',

  // Serveur de développement local (désactiver en production)
  server: {
    androidScheme: 'https',
    // url: 'http://192.168.x.x:5173', // Décommenter pour live reload sur Android
  },

  android: {
    // Icône de l'app (placer dans android/app/src/main/res/)
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false, // true pour déboguer
    backgroundColor: '#0f1923',
    // Permissions Android
    appendUserAgent: 'NyliramApp/1.0',
  },

  plugins: {
    // Stockage local (remplace window.storage en natif)
    Preferences: {
      group: 'NyliramData',
    },

    // Partage de fichiers (pour exporter les fiches de paie)
    Share: {},

    // Accès au système de fichiers (pour sauvegarder les fiches)
    Filesystem: {
      iosScheme: 'ionic',
    },

    // Barre de statut (Android)
    StatusBar: {
      style: 'dark',
      backgroundColor: '#0f1923',
    },

    // Écran de démarrage
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: '#0f1923',
      androidSplashResourceName: 'splash',
      showSpinner: false,
      androidScaleType: 'CENTER_CROP',
    },
  },
};

export default config;
