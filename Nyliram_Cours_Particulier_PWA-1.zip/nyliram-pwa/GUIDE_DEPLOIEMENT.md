# NYLIRAM COURS PARTICULIER
## Guide de déploiement — Android & Windows

---

## OPTION A — PWA (Installation immédiate, sans développeur)

### Sur Android (Chrome)
1. Ouvre l'application dans **Chrome sur Android**
2. Appuie sur le menu **⋮** (3 points en haut à droite)
3. Sélectionne **"Ajouter à l'écran d'accueil"** ou **"Installer l'application"**
4. Confirme → l'icône **Nyliram** apparaît sur ton écran d'accueil
5. Elle s'ouvre en plein écran, sans barre d'adresse, comme une vraie app

> ✅ Fonctionne hors connexion après la première utilisation
> ✅ Les données sont sauvegardées localement sur l'appareil
> ✅ Gratuit, aucun compte Play Store requis

### Sur Windows (Edge ou Chrome)
1. Ouvre l'application dans **Microsoft Edge** ou **Chrome**
2. Clique sur l'icône **d'installation** dans la barre d'adresse (⊕ ou 💻)
   - Edge : icône "+" à droite de la barre d'adresse
   - Chrome : icône ordinateur dans la barre d'adresse
3. Clique **"Installer"** dans la fenêtre qui s'ouvre
4. Nyliram apparaît dans le menu Démarrer et sur le bureau
5. Elle s'ouvre comme une application Windows normale

> ✅ Disponible dans le menu Démarrer → "Applications"
> ✅ Peut être épinglée à la barre des tâches
> ✅ Fonctionne hors connexion

---

## OPTION B — Application native Android (.apk)

### Prérequis
- Node.js 18+ installé : https://nodejs.org
- Android Studio : https://developer.android.com/studio
- Java JDK 17+ (inclus avec Android Studio)

### Étapes

```bash
# 1. Installer les dépendances
cd nyliram-pwa
npm install

# 2. Compiler l'application
npm run build

# 3. Initialiser Capacitor Android
npx cap add android

# 4. Synchroniser le build avec Android
npx cap sync android

# 5. Ouvrir dans Android Studio
npx cap open android
```

### Dans Android Studio
1. Attendre que Gradle se synchronise (2-5 minutes)
2. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**
3. Le fichier `.apk` est généré dans :
   `android/app/build/outputs/apk/debug/app-debug.apk`
4. Transférer le `.apk` sur le téléphone Android et l'installer

> ⚠️ Sur Android : activer "Sources inconnues" dans Paramètres → Sécurité
> pour installer un APK hors Play Store

### Pour publier sur le Play Store
1. Menu **Build → Generate Signed Bundle / APK**
2. Créer une clé de signature (keystore)
3. Générer le **AAB** (Android App Bundle)
4. Créer un compte Google Play Developer (25 $ une seule fois)
5. Publier sur https://play.google.com/console

---

## OPTION C — Application Windows (.exe)

### Via Capacitor Electron

```bash
# 1. Installer Electron pour Capacitor
npm install @capacitor-community/electron

# 2. Initialiser
npx cap add @capacitor-community/electron

# 3. Synchroniser
npx cap sync @capacitor-community/electron

# 4. Ouvrir et lancer
npx cap open @capacitor-community/electron
```

### Générer le .exe installable

```bash
# Dans le dossier electron généré
cd electron
npm install
npm run electron:build-windows
```

Le fichier `.exe` est généré dans `electron/dist/`

### Alternative simple : Tauri (plus léger)
```bash
# Installer Rust d'abord : https://rustup.rs
npm install @tauri-apps/cli
npx tauri init
npx tauri build
# Génère un .exe dans src-tauri/target/release/
```

---

## OPTION D — Service en ligne (sans code)

Si tu ne veux pas passer par le terminal :

| Service | Android | Windows | Prix |
|---------|---------|---------|------|
| **Median.co** | ✅ .apk | ❌ | ~$25/mois |
| **AppGyver** | ✅ | ✅ | Gratuit |
| **Expo EAS Build** | ✅ .apk | ❌ | Gratuit (limité) |
| **PWABuilder (Microsoft)** | ✅ | ✅ | Gratuit |

### PWABuilder (recommandé, gratuit)
1. Va sur https://www.pwabuilder.com
2. Entre l'URL de ton app déployée
3. Clique **"Package for stores"**
4. Télécharge le package Android ou Windows
5. Installe directement

---

## STRUCTURE DES FICHIERS

```
nyliram-pwa/
├── src/
│   ├── App.jsx          ← Application principale Nyliram
│   └── main.jsx         ← Point d'entrée React
├── public/
│   ├── index.html       ← HTML avec support PWA
│   ├── manifest.json    ← Métadonnées PWA (nom, icône, couleurs)
│   ├── sw.js            ← Service Worker (mode hors-ligne)
│   ├── icon-192.png     ← Icône app (à créer : fond #0f1923, "N" doré)
│   └── icon-512.png     ← Icône app haute résolution
├── capacitor.config.ts  ← Configuration Android & Windows
├── vite.config.js       ← Configuration build + PWA
└── package.json         ← Dépendances npm
```

---

## ICÔNES À CRÉER

Pour finaliser l'app, crée deux icônes :
- **icon-192.png** (192×192 px)
- **icon-512.png** (512×512 px)

Design suggéré : fond `#0f1923` (bleu nuit), lettre **"N"** en `#b8860b` (or),
police Playfair Display Bold.

Outil gratuit : https://maskable.app/editor ou https://realfavicongenerator.net

---

## DONNÉES & CONFIDENTIALITÉ

Les données (élèves, séances, fiches de paie) sont stockées **localement sur l'appareil**,
dans le navigateur (IndexedDB/LocalStorage) ou dans les préférences Capacitor.
Aucune donnée n'est envoyée sur un serveur externe.

Pour sauvegarder ou transférer les données :
- Utilise la fonction export/import JSON (à ajouter dans l'app si besoin)
- Ou synchronise le dossier de données via Google Drive / OneDrive

---

*Nyliram Cours Particulier — v1.0 — Mai 2026*
